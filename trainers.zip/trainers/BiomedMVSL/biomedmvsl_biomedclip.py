import copy
import os.path as osp
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.cuda.amp import GradScaler, autocast

from dassl.engine import TRAINER_REGISTRY, TrainerX
from dassl.utils import load_pretrained_weights, load_checkpoint
from dassl.optim import build_optimizer, build_lr_scheduler
from dassl.metrics import compute_accuracy
from trainers.prompt_templates import BIOMEDMVSL_TEMPLATES
from open_clip.src.open_clip import create_model_from_pretrained, get_tokenizer


class TextEncoder(nn.Module):
    def __init__(self, biomedclip_model):
        super().__init__()
        self.model = biomedclip_model
        self.dtype = biomedclip_model.text.transformer.dtype

    def forward(self, prompts, tokenized_prompts):
        x = self.model.encode_text(prompts, True, tokenized_prompts)

        return x


class PromptLearner(nn.Module):
    def __init__(self, cfg, classnames,
                 biomedclip_model):  # classnames['glioma tumor', 'meningioma tumor', 'pituitary tumor', 'normal brain']
        super().__init__()
        n_cls = len(classnames)  # 4
        n_ctx = cfg.TRAINER.BIOMEDMVSL.N_CTX  # 4
        ctx_init = cfg.TRAINER.BIOMEDMVSL.CTX_INIT  # 'a photo of a'
        dtype = biomedclip_model.text.transformer.dtype
        ctx_dim = 768
        clip_imsize = 224
        cfg_imsize = cfg.INPUT.SIZE[0]  # 224
        self.tokenizer = get_tokenizer('hf-hub:microsoft/BiomedCLIP-PubMedBERT_256-vit_base_patch16_224')
        assert cfg_imsize == clip_imsize, f"cfg_imsize ({cfg_imsize}) must equal to clip_imsize ({clip_imsize})"

        if ctx_init and n_ctx == 4:
            # use given words to initialize context vectors
            ctx_init = ctx_init.replace("_", " ")  # 'a photo of a'
            prompt = self.tokenizer(ctx_init)  # [1,256]
            with torch.no_grad():
                embedding = biomedclip_model.text.transformer.embeddings.word_embeddings(prompt).type(
                    dtype)  # [1, 256, 768]
            ctx_vectors = embedding[0, 1: 1 + n_ctx, :]  # [4, 768]
            prompt_prefix = ctx_init  # 'a photo of a'
        else:
            # random initialization
            if cfg.TRAINER.BIOMEDMVSL.CSC:
                print("Initializing class-specific contexts")
                ctx_vectors = torch.empty(n_cls, n_ctx, ctx_dim, dtype=dtype)
            else:
                print("Initializing a generic context")
                ctx_vectors = torch.empty(n_ctx, ctx_dim, dtype=dtype)
            nn.init.normal_(ctx_vectors, std=0.02)
            prompt_prefix = " ".join(["X"] * n_ctx)
        print(f'Initial text context: "{prompt_prefix}"')
        print(f"Number of context words (tokens) for Language prompting: {n_ctx}")
        self.ctx = nn.Parameter(ctx_vectors)  # [4, 768]

        classnames = [name.replace("_", " ") for name in
                      classnames]  # ['glioma tumor', 'meningioma tumor', 'pituitary tumor', 'normal brain']
        name_lens = [len(self.tokenizer(name)) for name in classnames]  # [1,1,1,1]
        prompts = [prompt_prefix + " " + name + "." for name in
                   classnames]  # ['a photo of a glioma tumor.', 'a photo of a meningioma tumor.', 'a photo of a pituitary tumor.', 'a photo of a normal brain.']

        tokenized_prompts = torch.cat([self.tokenizer(p) for p in prompts])  # (n_cls, n_tkn)[4, 256]
        # Also create frozen CLIP
        biomedclip_model_temp, _ = create_model_from_pretrained(
            'hf-hub:microsoft/BiomedCLIP-PubMedBERT_256-vit_base_patch16_224')
        biomedclip_model_temp = biomedclip_model_temp.float().eval().cuda()
        with torch.no_grad():
            embedding = biomedclip_model.text.transformer.embeddings.word_embeddings(tokenized_prompts).type(
                dtype)  # [4, 256, 768]
            self.ZS_image_encoder = biomedclip_model_temp.visual
            # Now pre-compute the frozen VL embeddings
            all_teacher_features = []

            for i in range(cfg.TRAINER.BIOMEDMVSL.N_PROMPTS):
                x_tokenized = torch.cat(
                    [self.tokenizer(BIOMEDMVSL_TEMPLATES[classname][i]) for classname in classnames])  # [4, 256]
                text_features = biomedclip_model_temp.encode_text(x_tokenized.cuda())  # [4, 512]
                all_teacher_features.append(text_features.unsqueeze(1))

        self.fixed_embeddings = torch.cat(all_teacher_features, dim=1)  # [4, 50, 512]
        # These token vectors will be saved when in save_model(),
        # but they should be ignored in load_model() as we want to use
        # those computed using the current class names
        self.register_buffer("token_prefix", embedding[:, :1, :])  # SOS[4,1,768]
        self.register_buffer("token_suffix", embedding[:, 1 + n_ctx:, :])  # CLS, EOS[4, 251, 768]

        self.n_cls = n_cls  # 4
        self.n_ctx = n_ctx  # 4
        self.tokenized_prompts = tokenized_prompts  # torch.Tensor[4, 256]
        self.name_lens = name_lens  # [1,1,1,1]
        self.class_token_position = cfg.TRAINER.BIOMEDMVSL.CLASS_TOKEN_POSITION  # 'end'

    def construct_prompts(self, ctx, prefix, suffix, label=None):
        # dim0 is either batch_size (during training) or n_cls (during testing)
        # ctx: context tokens, with shape of (dim0, n_ctx, ctx_dim)
        # prefix: the sos token, with shape of (n_cls, 1, ctx_dim)
        # suffix: remaining tokens, with shape of (n_cls, *, ctx_dim)

        prefix = self.token_prefix
        suffix = self.token_suffix

        if self.class_token_position == "end":
            prompts = torch.cat(
                [
                    prefix,  # (n_cls, 1, dim)
                    ctx,  # (n_cls, n_ctx, dim)
                    suffix,  # (n_cls, *, dim)
                ],
                dim=1,
            )
            # print('prompts', prompts.shape)
        elif self.class_token_position == "middle":
            half_n_ctx = self.n_ctx // 2
            prompts = []
            for i in range(self.n_cls):
                name_len = self.name_lens[i]
                prefix_i = prefix[i: i + 1, :, :]
                class_i = suffix[i: i + 1, :name_len, :]
                suffix_i = suffix[i: i + 1, name_len:, :]
                ctx_i_half1 = ctx[i: i + 1, :half_n_ctx, :]
                ctx_i_half2 = ctx[i: i + 1, half_n_ctx:, :]
                prompt = torch.cat(
                    [
                        prefix_i,  # (1, 1, dim)
                        ctx_i_half1,  # (1, n_ctx//2, dim)
                        class_i,  # (1, name_len, dim)
                        ctx_i_half2,  # (1, n_ctx//2, dim)
                        suffix_i,  # (1, *, dim)
                    ],
                    dim=1,
                )
                prompts.append(prompt)
            prompts = torch.cat(prompts, dim=0)
            # print('prompts', prompts.shape)
        elif self.class_token_position == "front":
            prompts = []
            for i in range(self.n_cls):
                name_len = self.name_lens[i]
                prefix_i = prefix[i: i + 1, :, :]
                class_i = suffix[i: i + 1, :name_len, :]
                suffix_i = suffix[i: i + 1, name_len:, :]
                ctx_i = ctx[i: i + 1, :, :]
                prompt = torch.cat(
                    [
                        prefix_i,  # (1, 1, dim)
                        class_i,  # (1, name_len, dim)
                        ctx_i,  # (1, n_ctx, dim)
                        suffix_i,  # (1, *, dim)
                    ],
                    dim=1,
                )
                prompts.append(prompt)
            prompts = torch.cat(prompts, dim=0)
            # print('prompts', prompts.shape)

        else:
            raise ValueError

        return prompts

    def forward(self):

        ctx = self.ctx
        if ctx.dim() == 2:
            ctx = ctx.unsqueeze(0).expand(self.n_cls, -1, -1)

        prefix = self.token_prefix
        suffix = self.token_suffix
        prompts = self.construct_prompts(ctx, prefix, suffix)  # [4, 256, 768]

        return prompts


def DSG_loss(student_feats: torch.Tensor, teacher_feats: torch.Tensor, temp: float = 0.5):
    """
    student_feats: [N, d]
    teacher_feats:  [N, d]
    """
    teacher_norm = torch.nn.functional.normalize(teacher_feats, p=2, dim=1)
    sim = torch.mm(teacher_norm, teacher_norm.T)  # [N, N]
    G = torch.exp(sim / temp)
    G.fill_diagonal_(0)

    diff = student_feats.unsqueeze(1) - student_feats.unsqueeze(0)  # [N, N, d]
    dist = (diff ** 2).sum(dim=-1)  # [N, N]

    loss = (G * dist).mean()
    return loss


class Adapter(nn.Module):
    def __init__(self, c_in, bottleneck=512):  # c_in:1024
        super(Adapter, self).__init__()
        self.fc1 = nn.Sequential(
            nn.Linear(c_in, bottleneck, bias=False),
            nn.LeakyReLU(inplace=False)
        )
        self.fc2 = nn.Sequential(
            nn.Linear(bottleneck, c_in, bias=False),
            nn.LeakyReLU(inplace=False)
        )

    def forward(self, x):
        x = self.fc1(x)
        y = self.fc2(x)
        return x, y


class CustomCLIP(nn.Module):
    def __init__(self, cfg, classnames, biomedclip_model):
        super().__init__()
        self.prompt_learner = PromptLearner(cfg, classnames, biomedclip_model)
        self.cfg = cfg
        self.tokenized_prompts = self.prompt_learner.tokenized_prompts
        self.image_encoder = biomedclip_model.visual
        self.text_encoder = TextEncoder(biomedclip_model)
        self.logit_scale = biomedclip_model.logit_scale
        self.dtype = biomedclip_model.text.transformer.dtype
        self.total_epochs = cfg.OPTIM.MAX_EPOCH
        self.n_cls = len(classnames)
        self.features_list = [11]  # [2, 5, 8, 11]
        self.VRAdapters = nn.ModuleList([Adapter(768, bottleneck=512) for i in range(len(self.features_list))])

        self.beta_1 = nn.Parameter(torch.tensor([0.5]), requires_grad=True)
        self.beta_2 = nn.Parameter(torch.tensor([0.5]), requires_grad=True)

    def forward(self, image, label=None):
        tokenized_prompts = self.tokenized_prompts
        logit_scale = self.logit_scale.exp()
        prompts = self.prompt_learner()

        # Compute the prompted image and text features
        text_features = self.text_encoder(prompts, tokenized_prompts)
        text_features = text_features / text_features.norm(dim=-1, keepdim=True)

        # Extract image features
        x = self.image_encoder.trunk.patch_embed(image.type(self.dtype))
        x = self.image_encoder.trunk._pos_embed(x)
        x = self.image_encoder.trunk.patch_drop(x)
        x = self.image_encoder.trunk.norm_pre(x)

        ########Visual Residual Adapter############################
        vra_mid_list = []
        for i in range(12):  # 12
            x = self.image_encoder.trunk.blocks[i](x)
            if (i + 1) in self.features_list:
                vra_mid, vra_out = self.VRAdapters[self.features_list.index(i + 1)](
                    x)  #
                x = 0.5 * x + 0.5 * vra_out
                vra_mid_list.append(vra_mid)

        x = self.image_encoder.trunk.norm(x)
        pooled = self.image_encoder.trunk.forward_head(x)
        pooled = self.image_encoder.head(pooled)
        pooled = pooled / pooled.norm(dim=-1, keepdim=True)

        # Compute the prompted logits
        logits = logit_scale * pooled @ text_features.t()

        ##########Local-level contrastive learning#########################
        logits_mid_list = []
        for layer in range(len(vra_mid_list)):
            tmp_vra_mid = vra_mid_list[layer][:, 1:] / vra_mid_list[layer][:, 1:].norm(dim=-1,
                                                                                       keepdim=True)  #
            logits_mid = 100.0 * torch.einsum("bpd,cd->bpc", tmp_vra_mid, text_features)  #
            logits_mid = torch.softmax(logits_mid, dim=-1)  #
            logits_mid = torch.mean(logits_mid, dim=1)  #
            logits_mid_list.append(logits_mid)

        ###########Dynamic fusion #####################################
        logits_final = self.beta_1 * logits + self.beta_2 * logits_mid_list[0]

        if self.prompt_learner.training:
            # Now calculate the frozen pre-trained features
            fixed_embeddings = self.prompt_learner.fixed_embeddings  #
            fixed_embeddings = fixed_embeddings / fixed_embeddings.norm(dim=-1, keepdim=True)
            with torch.no_grad():
                zero_shot_features = self.prompt_learner.ZS_image_encoder(image.type(self.dtype))
                zero_shot_features = zero_shot_features / zero_shot_features.norm(dim=-1, keepdim=True)

            fixed_embeddings = fixed_embeddings.mean(dim=1)
            fixed_embeddings = fixed_embeddings / fixed_embeddings.norm(dim=-1, keepdim=True)
            zero_shot_logits = logit_scale * zero_shot_features.cuda() @ fixed_embeddings.cuda().t()

            loss_ce = F.cross_entropy(logits, label)

            ##########Local-level contrastive learning loss#########################
            loss_mid = torch.zeros_like(loss_ce)
            for tmp_i in range(len(logits_mid_list)):
                tmp_logit_score = logits_mid_list[tmp_i]
                loss_mid += F.cross_entropy(tmp_logit_score, label)

            loss_mse = torch.nn.MSELoss()
            loss_dsg_mse = DSG_loss(
                text_features, fixed_embeddings.cuda()) + loss_mse(text_features,
                                                                   fixed_embeddings.cuda()) * self.cfg.TRAINER.BIOMEDMVSL.SCCM_LAMBDA

            loss_kdsp = F.kl_div(
                F.log_softmax(logits, dim=1),
                F.log_softmax(zero_shot_logits, dim=1),
                reduction='sum',
                log_target=True
            ) / logits.numel()

            loss_kdsp = loss_kdsp * self.cfg.TRAINER.BIOMEDMVSL.KDSP_LAMBDA

            return logits_final, loss_ce + loss_mid, loss_dsg_mse, loss_kdsp
        else:
            return logits_final


@TRAINER_REGISTRY.register()
class BiomedMVSL_BiomedCLIP(TrainerX):
    def check_cfg(self, cfg):
        assert cfg.TRAINER.BIOMEDMVSL.PREC in ["fp16", "fp32", "amp"]

    def build_model(self):
        cfg = self.cfg
        classnames = self.dm.dataset.classnames

        print(f"Loading BiomedCLIP (backbone: {cfg.MODEL.BACKBONE.NAME})")
        biomedclip_model, preprocess = create_model_from_pretrained(
            'hf-hub:microsoft/BiomedCLIP-PubMedBERT_256-vit_base_patch16_224')
        if cfg.TRAINER.BIOMEDMVSL.PREC == "fp32" or cfg.TRAINER.BIOMEDMVSL.PREC == "amp":
            biomedclip_model.float()

        print("Building custom CLIP")
        self.model = CustomCLIP(cfg, classnames, biomedclip_model.eval())

        print("Turning off gradients in both the image and the text encoder")
        names_to_update = ["prompt_learner.ctx", "VRAdapters.0.fc1.0.weight", "VRAdapters.0.fc2.0.weight",
                           # "VRAdapters.0.fc1.0.bias", "VRAdapters.0.fc2.0.bias",
                           "beta_1", "beta_2"
                           ]


        for name, param in self.model.named_parameters():
            print(name)
            if name not in names_to_update:
                param.requires_grad_(False)

        # Double check
        enabled = set()
        for name, param in self.model.named_parameters():
            print(name)
            if param.requires_grad:
                enabled.add(name)
        print(f"Parameters to be updated: {enabled}")
        print(f"Parameters count: {len(enabled)}")
        if cfg.MODEL.INIT_WEIGHTS:
            load_pretrained_weights(self.model, cfg.MODEL.INIT_WEIGHTS)

        self.model.to(self.device)
        # NOTE: only give prompt_learner to the optimizer
        self.optim = build_optimizer(self.model, cfg.OPTIM)
        self.sched = build_lr_scheduler(self.optim, cfg.OPTIM)
        self.register_model("prompt_learner", self.model, self.optim, self.sched)

        # Cosine scheduler
        self.total_epochs = cfg.OPTIM.MAX_EPOCH
        self.step_counter = 1
        self.scaler = GradScaler() if cfg.TRAINER.BIOMEDMVSL.PREC == "amp" else None
        # Note that multi-gpu training could be slow because CLIP's size is
        # big, which slows down the copy operation in DataParallel
        device_count = torch.cuda.device_count()
        if device_count > 1:
            print(f"Multiple GPUs detected (n_gpus={device_count}), use all of them!")
            self.model = nn.DataParallel(self.model)

    def forward_backward(self, batch):
        image, label = self.parse_batch_train(batch)

        model = self.model
        optim = self.optim
        scaler = self.scaler

        prec = self.cfg.TRAINER.BIOMEDMVSL.PREC
        if prec == "amp":
            with autocast():
                loss = model(image, label)
            optim.zero_grad()
            scaler.scale(loss).backward()
            scaler.step(optim)
            scaler.update()
        else:
            logits, loss_ce, loss_sccm, loss_kdsp = model(image, label)

            loss = loss_ce + loss_sccm + loss_kdsp
            self.model_backward_and_update(loss)

        loss_summary = {
            "loss": loss.item(),
            "acc": compute_accuracy(logits, label)[0].item(),
        }

        if (self.batch_idx + 1) == self.num_batches:
            self.update_lr()

        return loss_summary

    def parse_batch_train(self, batch):
        input = batch["img"]
        label = batch["label"]
        input = input.to(self.device)
        label = label.to(self.device)

        return input, label

    def load_model(self, directory, epoch=None):
        if not directory:
            print("Note that load_model() is skipped as no pretrained model is given")
            return

        names = self.get_model_names()

        # By default, the best model is loaded
        model_file = "model-best.pth.tar"

        if epoch is not None:
            model_file = "model.pth.tar-" + str(epoch)

        for name in names:
            model_path = osp.join(directory, name, model_file)

            if not osp.exists(model_path):
                raise FileNotFoundError('Model not found at "{}"'.format(model_path))

            checkpoint = load_checkpoint(model_path)
            state_dict = checkpoint["state_dict"]
            epoch = checkpoint["epoch"]

            # Ignore fixed token vectors
            if "prompt_learner.token_prefix" in state_dict:
                del state_dict["prompt_learner.token_prefix"]

            if "prompt_learner.token_suffix" in state_dict:
                del state_dict["prompt_learner.token_suffix"]

            print("Loading weights to {} " 'from "{}" (epoch = {})'.format(name, model_path, epoch))
            # set strict=False
            self._models[name].load_state_dict(state_dict, strict=False)
